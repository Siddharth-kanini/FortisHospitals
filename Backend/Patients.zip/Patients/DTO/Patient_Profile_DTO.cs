﻿namespace PatientApplication.DTO
{
    public class Patient_Profile_DTO
    {
        public string? Patient_Name { get; set; }
        public int Age { get; set; }
        public string? Gender { get; set; }
        public string? BloodGroup { get; set; }
        public string? Patient_Address { get; set; }
        public string Patient_Phone { get; set; }
    }
}
