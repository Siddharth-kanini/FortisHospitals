﻿namespace PatientApplication.DTO
{
    public class Patient_login_DTO
    {
        public string? Username { get; set; }
        public string? Password { get; set; }

    }
}
